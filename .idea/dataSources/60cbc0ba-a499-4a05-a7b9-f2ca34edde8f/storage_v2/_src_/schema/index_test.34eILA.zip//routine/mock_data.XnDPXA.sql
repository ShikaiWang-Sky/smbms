create
    definer = root@localhost function mock_data() returns int
begin
  declare num int default 1000000;
  declare i int default 0;
  
  while i < num do
    -- 插入语句
    insert into `app_user` (`name`,`email`,`phone`,`gender`,`password`,`age`) 
    values (concat('用户',i), '748945489@qq.com', concat('18',floor(rand()*100000000)),floor(rand()*2),uuid(),floor(rand()*100));
    set i = i + 1;
  end while;
  return i;
end;

